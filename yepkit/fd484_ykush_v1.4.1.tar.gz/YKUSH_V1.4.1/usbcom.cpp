/****************************************************************************
 FileName:      usbcom.cpp
 Dependencies:  See INCLUDES section
 Compiler:      g++
 Company:       Yepkit, Lda.

 Software License Agreement:

 Copyright (c) 2015 Yepkit Lda

 Permission is hereby granted, free of charge, to any person obtaining a copy
 of this software and associated documentation files (the "Software"), to deal
 in the Software without restriction, including without limitation the rights
 to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 copies of the Software, and to permit persons to whom the Software is
 furnished to do so, subject to the following conditions:

 The above copyright notice and this permission notice shall be included in
 all copies or substantial portions of the Software.

 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 THE SOFTWARE.

*****************************************************************************
 File Description:

    Change History:
        Rev     Date            Description
        ----    -----------     ---------------------------------------------
        1.0     2014-08-10      First Release
        1.1     2015-08-20      Buffers fixed at 64Bytes
        1.2     2015-09-06      Multiboard support by serial number addressing


 ****************************************************************************
 *  Summary:
 *
 *  Functions that communicate with the YKUSH board and/or provide
 *  status information.
 *
 ****************************************************************************/


//---------------------------------------------------------------------------
// INCLUDES
//---------------------------------------------------------------------------
#include <errno.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <libusb-1.0/libusb.h>
#include "usbcom.h"
#include <iostream>

using namespace std;


//---------------------------------------------------------------------------
// DEFINES
//---------------------------------------------------------------------------
#define VERSION "0.1.0"             // ToDo -  Validar se é necessário...
#define VENDOR_ID 0x04D8
#define PRODUCT_ID 0xF2F7
#define OLD_PRODUCT_ID 0x0042

// HID Class-Specific Requests values. See section 7.2 of the HID specifications
#define HID_GET_REPORT                0x01
#define HID_GET_IDLE                  0x02
#define HID_GET_PROTOCOL              0x03
#define HID_SET_REPORT                0x09
#define HID_SET_IDLE                  0x0A
#define HID_SET_PROTOCOL              0x0B
#define HID_REPORT_TYPE_INPUT         0x01
#define HID_REPORT_TYPE_OUTPUT        0x02
#define HID_REPORT_TYPE_FEATURE       0x03

#define CTRL_IN         LIBUSB_ENDPOINT_IN|LIBUSB_REQUEST_TYPE_CLASS|LIBUSB_RECIPIENT_INTERFACE
#define CTRL_OUT        LIBUSB_ENDPOINT_OUT|LIBUSB_REQUEST_TYPE_CLASS|LIBUSB_RECIPIENT_INTERFACE



//---------------------------------------------------------------------------
// DECLARATIONS
//---------------------------------------------------------------------------
const static int PACKET_CTRL_LEN=2;
const static int PACKET_INT_LEN=6;
const static int INTERFACE=0;
const static int ENDPOINT_INT_IN=0x81; /* endpoint 0x81 address for IN */
const static int ENDPOINT_INT_OUT=0x01; /* endpoint 1 address for OUT */
const static int TIMEOUT=5000; /* timeout in ms */
const static int TIMEOUT_EXEC_CMD=120000; /* timeout in ms */



static libusb_device_handle *devh = NULL;
static libusb_context *ctx;
static libusb_device **list;


//Flags
static bool interfaceClaimed = false;
static bool devOpen = false;
static bool listFetched = false;
static bool usbInit = false;








/**********************************************************************************
 *
 * MULTIBOARD COMMAND BASED ON iSerialNumber
 *
 *---------------------------------------------------------------------------------
 *
 *  DESCRIPTION:
 *
 *      Function that issues a command to a YKUSH board with the specific
 *      serial number provided as input.
 *
 *  DEPENDENCIES:
 *
 *      The following external variables have to be declared:
 *
 *          static libusb_device_handle *devh
 *          static libusb_context *ctx
 *          static bool interfaceClaimed
 *          static bool devOpen
 *          static bool listFetched
 *          static bool usbInit
 *
 *  INPUTS:
 *
 *      iSerial -   YKUSH board serial number
 *      cmd     -   command byte to be sent to the YKUSH board
 *
 *  OUTPUTS:
 *
 *      0   -   Ok
 *      -1  -   ERROR: Failed to initialise libusb
 *      -2  -   ERROR: Unable to open YKUSH control device
 *      -3  -   ERROR: Unable to transmit command successfuly to YKUSH board
 *
 **********************************************************************************/
char commandBySerial(char *iSerial, char cmd) {

    int number;
    char err = 0;
    char output = 0x00;

    //libusb init
    int r = 1;
    r = libusb_init(&ctx);
    if (r < 0) {
        fprintf(stderr, "commandBySerial: Failed to initialise libusb\n");
        err = -1;
        goto clean;
    }
    usbInit = true;

    if (verbose) {
        printf("commandBySerial: Libusb initialized...\n");
    }

    //get YKUSH device with Serial Number = iSerial
    r = openDeviceByID(iSerial);
    if(r < 0) {
        fprintf(stderr, "commandBySerial: Unable to open YKUSH control device with serial number: %s\n openDeviceByID returned ERROR: %d", iSerial, r);
        err = -2;
        goto clean;
    }

    if (verbose) {
        printf("commandBySerial: YKUSH device open...\n");
    }

    char numberString[5];

    numberString[0] = iSerial[2];
    numberString[1] = iSerial[3];
    numberString[2] = iSerial[4];
    numberString[3] = iSerial[5];
    numberString[4] = iSerial[6];

    number = atoi(numberString);

    //send command to device
    unsigned char toSendBuffer[64], receivedBuffer[64];
    toSendBuffer[0]= cmd;
    toSendBuffer[1]= cmd;
    if(number < 20400){
        if (verbose) {
            printf("commandBySerial: Old firmware detected, using sendCommand6...\n");
        }
        err = sendCommand6(toSendBuffer, receivedBuffer);
        if (err != 0) {
            err = -3;
            goto clean;
        }
    } else {
        if (verbose) {
            printf("commandBySerial: Calling sendCommand function...\n");
        }
        err = sendCommand(toSendBuffer, receivedBuffer);
        output = receivedBuffer[1];
        if (err != 0) {
            err = -3;
            goto clean;
        }
    }


//libsub cleanup tasks
clean:
    if (interfaceClaimed) {
        if (verbose) {
            printf("commandBySerial: interfaceClaimed flag is set...\n");
        }
        err = libusb_release_interface(devh, INTERFACE);
        if (err != 0) {
            printf("commandBySerial: ERROR - libusb_release_interface returned an error\n");
        } else {
            if (verbose) {
                printf("commandBySerial: libusb_release_interface executed sucessfully...\n");
            }
        }
    }
    if (devOpen) {
        if (verbose) {
            printf("commandBySerial: devOpen flag is set...\n");
        }
        assert(devh != NULL);
        libusb_reset_device(devh);
        libusb_close(devh);
    }
    if (listFetched) {
        if (verbose) {
            printf("commandBySerial: listFetched flag is set...\n");
        }
        libusb_free_device_list(list, 1);
    }
    if (usbInit) {
        if (verbose) {
            printf("commandBySerial: usbInit flag is set...\n");
        }
        libusb_exit(ctx);
    }


    if (verbose) {
        printf("commandBySerial: libusb closed...\n");
    }

    return output;

}






/*********************************************************************************
 *
 *  OPENS YKUSH BY SERIAL NUMBER
 *
 *--------------------------------------------------------------------------------
 *
 *  DESCRIPTION:
 *
 *  This funtion finds the connected YKUSH boards and opens the one matching
 *  the Serial Number provided as input.
 *  Also the device configuration and interface claim is handled by this function.
 *
 *
 *  DEPENDENCIES:
 *
 *      - Libusb has to be already initialized.
 *      - VENDOR_ID and PRODUCT_ID must be globaly defined.
 *      - INTERFACE has to be defined with the interface_number.
 *
 *      devh  -   pointer to a libusb_device_handle
 *
 *
 *  INPUTS:
 *
 *      iSerial -   Pointer to the char array / string containing the serial number
 *                  of YKUSH device to be open.
 *
 *
 *
 *  OUTPUTS:
 *
 *      0   -   OK
 *      -1  -   ERROR: No device found with the supplied iSerial
 *      -2  -   ERROR: Unable to set configuration
 *      -3  -   ERROR: Unable to claim interface
 *      -4  -   ERROR: Unable to detach kernel driver from device interface
 *      -5  -   ERROR: Unable to get device descriptor
 *      -6  -   ERROR: Unable to fetch device list
 *
 *
 *********************************************************************************/
int openDeviceByID(char *iSerial) {

    if (verbose) {
        printf("openDeviceByID: Entering openDeviceByID function...\n");
    }

    //discover devices
    ssize_t cnt = libusb_get_device_list(ctx, &list);
    if (cnt < 0){
        return -6;
    }
    listFetched = true;
    if (verbose) {
        printf("openDeviceByID: Obtained device list...\n");
    }

    int i = 0;
    int err = 0;
    int r = 0;
    for (i = 0; i < cnt; i++) {
        libusb_device *device = list[i];
        if (verbose) {
            printf("openDeviceByID: Iterating through device #%d...\n",i+1);
        }

        //get the device descriptor
        struct libusb_device_descriptor desc;
        err = libusb_get_device_descriptor(device,&desc);
        if (err!=0) {
            return -5;
        }
        if (verbose) {
            printf("openDeviceByID: Device descriptor fetched...\n");
        }

        //check if it is a YKUSH board
        if (desc.idVendor == VENDOR_ID && desc.idProduct == PRODUCT_ID) {
            if (verbose) {
                printf("openDeviceByID: YKUSH board detected...\n");
            }

            //open YKUSH control device
            r = libusb_open(device, &devh);
            if(r!=0) {
                return -1;
            }
            devOpen = true;
            if (verbose) {
                printf("openDeviceByID: Device open...\n");
            }

            r = libusb_detach_kernel_driver(devh, INTERFACE);
            if (verbose) {
                printf("\nopenDeviceByID: libusb_detach_kernel_driver returned %d code...\n", r);
            }

            //get iSerialNumber
            unsigned char sSerial[256];
            char usSerial[256];


            libusb_get_string_descriptor_ascii( devh, desc.iSerialNumber, sSerial, 255);
            //copy sSerial to usSerial
            int j;
            for(j=0; j<255; j++) {
                usSerial[j] = sSerial[j];
            }

            //check if matches the iSerial
            if(strcmp(usSerial, iSerial)==0){
                if (verbose) {
                    printf("openDeviceByID: YKUSH board with serial number %s found...\n",iSerial);
                }

                //configure device
                r = libusb_set_configuration(devh, 1);
                if(r!=0) {
                    return -2;
                }
                if (verbose) {
                    printf("openDeviceByID: Configuration set for device...\n");
                }

                //claim interface
                r = libusb_claim_interface(devh, INTERFACE);
                if(r!=0) {
                    return -3;
                }
                interfaceClaimed = true;
                if (verbose) {
                    printf("openDeviceByID: Device interface %d claimed...\n",INTERFACE);
                }

                return 0;

            }

        }
        if (verbose) {
            printf("\n");
        }

    }

    if (verbose) {
        printf("openDeviceByID: Finish device list parsing...\n");
    }

    return -1;
}











/**************************************************************************
 * printSerialNumber() - List YKUSH Devices Serial Number
 *-------------------------------------------------------------------------
 *
 * This function prints the iSerial of the
 * attached YKUSH devices.
 *
 **************************************************************************/
int printSerialNumber() {
    // USB init
    int r = 1;
    int err = 0;
    r = libusb_init(NULL);
    if (r < 0) {
        fprintf(stderr, "Failed to initialise libusb\n");
        exit(1);
    }

    // discover devices
    ssize_t cnt = libusb_get_device_list(NULL, &list);
    ssize_t i = 0;

    if (cnt < 0){
        fprintf(stderr, "Failed to get device list\n");
        exit(1);
    }

    for (i = 0; i < cnt; i++) {
        libusb_device *device = list[i];

        //get the device descriptor
        struct libusb_device_descriptor desc;
        libusb_get_device_descriptor(device,&desc);

        //Check if it is a YKUSH board
        if (desc.idVendor == VENDOR_ID && desc.idProduct == PRODUCT_ID) {

            //open YKUSH device
            libusb_device_handle *handle;
            err = libusb_open(device, &handle);
            if (err != 0) {
                fprintf(stderr, "printSerialNumber: Failed to open device\n");
                exit(0);
            }

            //get iSerialNumber
            unsigned char sSerial[256];
            libusb_get_string_descriptor_ascii( handle, desc.iSerialNumber, sSerial, 255);

            cout << sSerial;
            cout << "\n";

            //close device
            libusb_reset_device(handle);
            libusb_close(handle);

        }
    }


    /* Close */
    libusb_free_device_list(list, 1);
    libusb_exit(NULL);

    return 0;
}







/**************************************************************************
 * sendCommand() - Sends command and waits response
 *-------------------------------------------------------------------------
 *
 * This function sends a command to YKUSH board using the standard
 * 64 Bytes reports.
 *
 **************************************************************************/
 int sendCommand(unsigned char *toSendBuffer, unsigned char *receivedBuffer)
 {
        int r;
        int transferred;


     r = libusb_interrupt_transfer(devh, ENDPOINT_INT_OUT, toSendBuffer, 64,
         &transferred,TIMEOUT);
     if (r < 0) {
         cout << "Interrupt write error";
         cout << r;
         return r;
     }
     
     r = libusb_interrupt_transfer(devh, ENDPOINT_INT_IN, receivedBuffer,64,
         &transferred, TIMEOUT_EXEC_CMD);
     if (r < 0) {
         fprintf(stderr, "Interrupt read error %d\n", r);
         cout << "Interrupt read error ";
         cout << r;
         return r;
     }
     
     if (transferred < PACKET_INT_LEN) {
         fprintf(stderr, "Interrupt transfer short read (%d)\n", r);
         cout << "Interrupt transfer short read ";
         cout << r;
         return -1;
     }

     return 0;
 }




 /**************************************************************************
  * sendCommand6() - Sends command and waits response - LEGACY
  *-------------------------------------------------------------------------
  *
  * This function sends a command to YKUSH board using the old
  * 6 Bytes reports.
  *
  * Only for backwards compatibility with old YKUSH firmware versions.
  *
  **************************************************************************/
 int sendCommand6(unsigned char *toSendBuffer, unsigned char *receivedBuffer)
 {
        int r;
        int transferred;


     r = libusb_interrupt_transfer(devh, ENDPOINT_INT_OUT, toSendBuffer, 6,
         &transferred,TIMEOUT);
     if (r < 0) {
         cout << "Interrupt write error";
         cout << r;
         return r;
     }

     r = libusb_interrupt_transfer(devh, ENDPOINT_INT_IN, receivedBuffer,6,
         &transferred, TIMEOUT_EXEC_CMD);
     if (r < 0) {
         fprintf(stderr, "Interrupt read error %d\n", r);
         cout << "Interrupt read error ";
         cout << r;
         return r;
     }

     if (transferred < PACKET_INT_LEN) {
         fprintf(stderr, "Interrupt transfer short read (%d)\n", r);
         cout << "Interrupt transfer short read ";
         cout << r;
         return -1;
     }

     return 0;
 }




 /********************************************************************************
  *
  * SENDS COMMAND TO THE FIRST YKUSH BOARD CONNECTED TO THE HOST
  *
  *-------------------------------------------------------------------------------
  *
  * DESCRIPTION:
  *
  *     This function sends the command byte to the first YKUSH board connected
  *     into the host.
  *
  *     When more than one YKUSH boards are connected to the same host the
  *     the function commandBySerial should be used instead.
  *
  * DEPENDENCIES:
  *
  *     The following external variables have to be declared:
  *
  *         static libusb_device_handle *devh
  *         static libusb_context *ctx
  *         static bool interfaceClaimed
  *         static bool devOpen
  *         static bool listFetched
  *         static bool usbInit
  *
  * INPUTS:
  *
  *     cmd     -   command byte to be sent to the YKUSH board
  *
  * OUTPUTS:
  *
  *     0   -   OK
  *
  ********************************************************************************/
 char command(char cmd)
 {
    // USB INIT
    int r = 1;
    unsigned char toSendBuffer[64], receivedBuffer[64];
    int number;
    char err = 0;
    libusb_device *dev;
    char output = 0x00;


    r = libusb_init(&ctx);
    if (r < 0) {
        fprintf(stderr, "Failed to initialise libusb\n");
        goto clean;
    }
    usbInit = true;
    
    
    
    devh = libusb_open_device_with_vid_pid(ctx, VENDOR_ID, PRODUCT_ID);
    if (devh == NULL) {

        // Try OLD PID - Legacy Support
        devh = libusb_open_device_with_vid_pid(ctx, VENDOR_ID, OLD_PRODUCT_ID);
        if (devh == NULL) {
            fprintf(stderr, "Could not open YKUSH control device\n");
            goto clean;
        }
    } 
    devOpen = true;
    
    libusb_detach_kernel_driver(devh, INTERFACE);

    r = libusb_set_configuration(devh, 1);
    if (r < 0) {
        fprintf(stderr, "libusb_set_configuration error %d\n", r);
        goto clean;
    }
    
    r = libusb_claim_interface(devh, 0);
    if (r < 0) {
        fprintf(stderr, "libusb_claim_interface error %d\n", r);
        goto clean;
    }

    interfaceClaimed = true;

    //Access firmware version
    //get the USB device
    dev = libusb_get_device(devh);


    //get the device descriptor
    struct libusb_device_descriptor desc;
    libusb_get_device_descriptor(dev,&desc);

    //get iSerialNumber
    unsigned char sSerial[256];
    libusb_get_string_descriptor_ascii( devh, desc.iSerialNumber, sSerial, 255);

    char numberString[5];

    numberString[0] = sSerial[2];
    numberString[1] = sSerial[3];
    numberString[2] = sSerial[4];
    numberString[3] = sSerial[5];
    numberString[4] = sSerial[6];

    number = atoi(numberString);

    /*  SEND COMMANDS */
    toSendBuffer[0]= cmd;
    toSendBuffer[1]= cmd;
    if(number < 20400){
        sendCommand6(toSendBuffer, receivedBuffer);
    } else {
        sendCommand(toSendBuffer, receivedBuffer);
        output = receivedBuffer[1];
    }


    //libsub cleanup tasks
clean:
    if (interfaceClaimed) {
        if (verbose) {
            printf("command: interfaceClaimed flag is set...\n");
        }
        err = libusb_release_interface(devh, INTERFACE);
        if (err != 0) {
            printf("command: ERROR - libusb_release_interface returned an error\n");
        } else {
            if (verbose) {
                printf("command: libusb_release_interface executed sucessfully...\n");
            }
        }
    }
    if (devOpen) {
        if (verbose) {
            printf("command: devOpen flag is set...\n");
        }
        assert(devh != NULL);
        libusb_reset_device(devh);
        libusb_close(devh);
    }
    if (listFetched) {
        if (verbose) {
            printf("command: listFetched flag is set...\n");
        }
        libusb_free_device_list(list, 1);
    }
    if (usbInit) {
        if (verbose) {
            printf("command: usbInit flag is set...\n");
        }
        libusb_exit(ctx);
    }


    if (verbose) {
        printf("command: libusb closed...\n");
    }


    return output;

 }
 
 








