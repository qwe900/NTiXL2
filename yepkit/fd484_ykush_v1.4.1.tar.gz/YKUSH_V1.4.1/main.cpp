/****************************************************************************
 FileName:      main.cpp
 Dependencies:  See INCLUDES section
 Compiler:      g++
 Company:       Yepkit, Lda.

 Software License Agreement:

 Copyright (c) 2014 Yepkit Lda

 Permission is hereby granted, free of charge, to any person obtaining a copy
 of this software and associated documentation files (the "Software"), to deal
 in the Software without restriction, including without limitation the rights
 to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 copies of the Software, and to permit persons to whom the Software is
 furnished to do so, subject to the following conditions:

 The above copyright notice and this permission notice shall be included in
 all copies or substantial portions of the Software.

 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 THE SOFTWARE.

*****************************************************************************
 File Description:

    Change History:
        Rev     Date            Description
        ----    -----------     ---------------------------------------------
        1.0     2014-08-10      First Release
        1.2     2015-09-06      Multiboard support by serial number addressing


 ****************************************************************************
 *  Summary:
 *      Main program function
 *
 *
 *
*****************************************************************************/


// INCLUDES -----------------------------------------------------------------
#include <cstdlib>
#include <iostream>
#include <stdio.h>
#include <getopt.h>
#include <string.h>

#include "usbcom.h"


using namespace std;


// DECLARATIONS -------------------------------------------------------------
int printUsage();

enum cmdAction {
    PORT_UP,
    PORT_DOWN,
    LIST_DEVICES,
    DISPLAY_SERIAL_NUMBER,
    GET_PORT_STATUS,
    PRINT_HELP,
};

extern bool verbose = false;       //flag if command should run in high verbosity mode


// MAIN PROGRAM -------------------------------------------------------------
int main(int argc, char** argv) {


    char cmd = 0x00;
    char response;

    //if no arguments were provided then show usage and terminate program
    if ( argc <= 1){
        printUsage();
        return 0;
    }

    //go through the arguments and define action to be taken
    enum cmdAction action = PRINT_HELP;
    bool addressed = false;     //flag if a specific board should be addressed by the serial number (only relevant when multiple YKUSH boards are simultaneously connected to the same host)
    char *iSerial;
    int opt;
    int port = 0;               //0 = all ports
    while ((opt = getopt(argc, argv, "d:u:ivlsg:")) != -1) {
        switch (opt) {

        case 'd':
            action = PORT_DOWN;
            if (verbose) {
                printf("PORT_DOWN option detected...\n");
            }
            if (!strcmp(optarg, "a")) {
                port = 0;   //all ports
                if (verbose) {
                    printf("PORT_DOWN to be applied to all ports...\n");
                }
            } else {
                port = atoi(optarg);
                if (verbose) {
                    printf("PORT_DOWN to be applied to port %d...\n", port);
                }
                if (port > 3) {
                    printUsage();
                    return -1;
                }
            }
            break;

        case 'u':
            action = PORT_UP;
            if (!strcmp(optarg, "a")) {
                port = 0;   //all ports
            } else {
                port = atoi(optarg);
                if (port > 3) {
                    printUsage();
                    return -1;
                }
            }
            break;

        case 'l':
            action = LIST_DEVICES;
            break;

        case 'i':
            action = DISPLAY_SERIAL_NUMBER;
            break;

        case 'v':
            verbose = true;
            printf("\nYKUSH command running with high verbosity...\n");
            break;

        case 's':
            addressed = true;
            iSerial = optarg;
            if (verbose) {
                printf("Command to be applied to the board with serial number %s...\n", iSerial);
            }
            break;

        case 'g':
            action = GET_PORT_STATUS;
            port = atoi(optarg);
            if (verbose) {
                printf("Requesting downstream port %d status...\n", port);
            }
            if (port > 3) {
                printUsage();
                return -1;
            }
            break;

        default:
            printUsage();
            break;
        }
    }

    //issue the commands
    if (action == PORT_DOWN) {
        if (addressed) {    //target board specified by serial number
            if (port==0) {
                //all downstreams down
                cmd = 0x0a;
                if (verbose) {
                    printf("Requesting a PORT_DOWN command for all ports (cmd=0x%02x) addressed by serial number...\n", cmd);
                }
                commandBySerial(iSerial,cmd);
            } else {
                switch (port) {
                case 1:
                    //downstream 1 down
                    cmd = 0x01;
                    commandBySerial(iSerial,cmd);
                    break;
                case 2:
                    //downstream 2 down
                    cmd = 0x02;
                    commandBySerial(iSerial,cmd);
                    break;
                case 3:
                    //downstream 3 down
                    cmd = 0x03;
                    commandBySerial(iSerial,cmd);
                    break;
                default:
                    printUsage();
                    return -1;
                    break;
                }
            }
        } else {    //target board NOT specified by serial number
            if (port==0) {
                //all downstreams down
                cmd = 0x0a;
                if (verbose) {
                    printf("Requesting a PORT_DOWN command for all ports (cmd=0x%02x)...\n", cmd);
                }
                command(cmd);
            } else {
                switch (port) {
                case 1:
                    //downstream 1 down
                    cmd = 0x01;
                    command(cmd);
                    break;
                case 2:
                    //downstream 2 down
                    cmd = 0x02;
                    command(cmd);
                    break;
                case 3:
                    //downstream 3 down
                    cmd = 0x03;
                    command(cmd);
                    break;
                default:
                    printUsage();
                    return -1;
                    break;
                }
            }
        }
    }

    if (action == PORT_UP) {
        if (addressed) {
            if (port==0) {
                //all downstreams up
                cmd = 0x1a;
                commandBySerial(iSerial,cmd);
            } else {
                switch (port) {
                case 1:
                    //downstream 1 up
                    cmd = 0x11;
                    commandBySerial(iSerial,cmd);
                    break;
                case 2:
                    //downstream 2 up
                    cmd = 0x12;
                    commandBySerial(iSerial,cmd);
                    break;
                case 3:
                    //downstream 3 up
                    cmd = 0x13;
                    commandBySerial(iSerial,cmd);
                    break;
                default:
                    printUsage();
                    return -1;
                    break;
                }
            }
        } else {
            if (port==0) {
                //all downstreams up
                cmd = 0x1a;
                command(cmd);
            } else {
                switch (port) {
                case 1:
                    //downstream 1 up
                    cmd = 0x11;
                    command(cmd);
                    break;
                case 2:
                    //downstream 2 up
                    cmd = 0x12;
                    command(cmd);
                    break;
                case 3:
                    //downstream 3 up
                    cmd = 0x13;
                    command(cmd);
                    break;
                default:
                    printUsage();
                    return -1;
                    break;
                }
            }
        }
    }

    if (action == DISPLAY_SERIAL_NUMBER) {
        printSerialNumber();
    }

    if (action == LIST_DEVICES) {
        printSerialNumber();
    }


    if (action == GET_PORT_STATUS) {
        if (addressed) {    //target board specified by serial number
            if (port==0) {
                // TBD
            } else {
                switch (port) {
                case 1:
                    //downstream 1 status
                    cmd = 0x21;
                    response = commandBySerial(iSerial,cmd);
                    if (response == 0x11) {
                        printf("\nDownstream port 1 is: UP\n");
                    } else if (response == 0x01) {
                        printf("\nDownstream port 1 is: DOWN\n");
                    } else {
                        printf("\nUnable to get port status\n");
                    }
                    break;
                case 2:
                    //downstream 2 status
                    cmd = 0x22;
                    response = commandBySerial(iSerial,cmd);
                    if (response == 0x12) {
                        printf("\nDownstream port 2 is: UP\n");
                    } else if (response == 0x02) {
                        printf("\nDownstream port 2 is: DOWN\n");
                    } else {
                        printf("\nUnable to get port status\n");
                    }
                    break;
                case 3:
                    //downstream 3 status
                    cmd = 0x23;
                    response = commandBySerial(iSerial,cmd);
                    if (response == 0x13) {
                        printf("\nDownstream port 3 is: UP\n");
                    } else if (response == 0x03) {
                        printf("\nDownstream port 3 is: DOWN\n");
                    } else {
                        printf("\nUnable to get port status\n");
                    }
                    break;
                default:
                    printUsage();
                    return -1;
                    break;
                }
            }
        } else {    //target board NOT specified by serial number
            if (port==0) {
                //TBD
            } else {
                switch (port) {
                case 1:
                    //downstream 1 status
                    cmd = 0x21;
                    response = command(cmd);
                    if (response == 0x11) {
                        printf("\nDownstream port 1 is: UP\n");
                    } else if (response == 0x01) {
                        printf("\nDownstream port 1 is: DOWN\n");
                    } else {
                        printf("\nUnable to get port status\n");
                    }
                    break;
                case 2:
                    //downstream 2 status
                    cmd = 0x22;
                    response = command(cmd);
                    if (response == 0x12) {
                        printf("\nDownstream port 2 is: UP\n");
                    } else if (response == 0x02) {
                        printf("\nDownstream port 2 is: DOWN\n");
                    } else {
                        printf("\nUnable to get port status\n");
                    }
                    break;
                case 3:
                    //downstream 3 status
                    cmd = 0x23;
                    response = command(cmd);
                    if (response == 0x13) {
                        printf("\nDownstream port 3 is: UP\n");
                    } else if (response == 0x03) {
                        printf("\nDownstream port 3 is: DOWN\n");
                    } else {
                        printf("\nUnable to get port status\n");
                    }
                    break;
                default:
                    printUsage();
                    return -1;
                    break;
                }
            }
        }
    }

        
 
    return 0;
}





int printUsage(){

    printf("\nUsage:\n");
    printf("\nykush -d downstream_number \t\tTurns DOWN the downstream port with the number downstream_number\n");
    printf("\nykush -u downstream_number \t\tTurns UP the downstream port with the number downstream_number\n");
    printf("\nykush -s serial_number \t\t\tSpecifies the board with serial_number as the target of the command\n");
    printf("\nykush -i \t\t\t\tPrints the iSerialNumber\n");
    printf("\nykush -l \t\t\t\tLists all currently attached YKUSH boards\n");
    printf("\nykush -g downstream_number \t\tGet the status of the downstream port with the number downstream_number\n");

    return 0;
}
