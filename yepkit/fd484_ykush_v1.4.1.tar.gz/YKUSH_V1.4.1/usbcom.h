#ifndef USBCOM_H
#define USBCOM_H

#include <libusb-1.0/libusb.h>

int sendCommand(unsigned char *toSendBuffer, unsigned char *receivedBuffer);
int sendCommand6(unsigned char *toSendBuffer, unsigned char *receivedBuffer);

char command(char cmd);

int commandMultiBoard(int pid, char cmd);

int printSerialNumber();

char commandBySerial(char *iSerial, char cmd);

int openDeviceByID(char *iSerial);


//Globals
extern bool verbose;

#endif // USBCOM_H
